# Cost-aware mitigation policy.
