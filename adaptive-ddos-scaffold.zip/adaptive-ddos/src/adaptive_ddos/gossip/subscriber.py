# Verdict validation, deduplication, and expiry scaffold.
