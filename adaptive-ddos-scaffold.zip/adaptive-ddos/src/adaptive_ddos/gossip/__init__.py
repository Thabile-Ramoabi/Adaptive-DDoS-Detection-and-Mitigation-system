# Authenticated inter-router verdict propagation.
