# Versioned gossip serialization scaffold.
