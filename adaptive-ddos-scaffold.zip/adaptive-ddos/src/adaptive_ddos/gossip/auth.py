# Authentication hooks; see ADR-004 before implementation.
