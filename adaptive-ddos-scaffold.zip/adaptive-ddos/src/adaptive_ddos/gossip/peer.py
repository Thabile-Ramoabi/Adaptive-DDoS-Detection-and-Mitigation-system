# Peer identity and trust state scaffold.
