# Shared configuration helpers.
