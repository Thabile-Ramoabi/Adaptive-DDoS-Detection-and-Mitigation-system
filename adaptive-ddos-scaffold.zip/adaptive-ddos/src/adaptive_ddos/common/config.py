# Configuration loader scaffold.
