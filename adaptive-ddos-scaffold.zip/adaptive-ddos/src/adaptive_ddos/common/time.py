# Shared time and expiry utilities scaffold.
