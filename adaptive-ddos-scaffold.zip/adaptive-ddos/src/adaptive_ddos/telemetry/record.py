# Typed feature record representation scaffold.
