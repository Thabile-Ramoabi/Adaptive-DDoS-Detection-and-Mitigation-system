# Feature record ingestion and validation.
