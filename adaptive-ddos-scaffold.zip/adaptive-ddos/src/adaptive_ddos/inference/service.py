# Inference service interface scaffold.
