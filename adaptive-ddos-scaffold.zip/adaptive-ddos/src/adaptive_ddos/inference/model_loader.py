# Versioned model loading scaffold.
