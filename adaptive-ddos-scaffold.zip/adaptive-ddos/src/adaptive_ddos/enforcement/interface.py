# Backend-independent enforcement interface scaffold.
