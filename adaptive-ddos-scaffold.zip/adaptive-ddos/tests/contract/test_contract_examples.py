import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]
CONTRACTS = ROOT / "contracts" / "v1"
EXAMPLES = CONTRACTS / "examples"


class ContractExampleTests(unittest.TestCase):
    def test_schema_files_are_valid_json(self):
        for path in CONTRACTS.glob("*.schema.json"):
            with self.subTest(schema=path.name):
                self.assertIsInstance(json.loads(path.read_text(encoding="utf-8")), dict)

    def test_feature_record_has_shared_envelope(self):
        record = json.loads((EXAMPLES / "feature-record.json").read_text(encoding="utf-8"))
        self.assertTrue({"schema_version", "record_id", "router_id", "window", "flow", "feature_manifest_version", "features"} <= record.keys())

    def test_verdict_score_and_action_are_in_range(self):
        verdict = json.loads((EXAMPLES / "verdict.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(verdict["score"], 0)
        self.assertLessEqual(verdict["score"], 1)
        self.assertIn(verdict["action"], {"allow", "rate_limit", "challenge", "xdp_drop", "upstream_blackhole"})


if __name__ == "__main__":
    unittest.main()
