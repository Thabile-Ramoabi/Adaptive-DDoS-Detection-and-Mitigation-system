/* Export records aligned with contracts/v1. */
