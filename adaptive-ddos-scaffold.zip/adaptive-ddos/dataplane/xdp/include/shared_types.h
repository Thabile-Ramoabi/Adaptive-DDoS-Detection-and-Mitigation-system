/* Align kernel/userspace structures with the approved telemetry contract. */
