/* XDP scaffold only; packet behavior is not implemented. */
