# Linux dataplane

Student 2 owns this area. Begin with bounded packet counters and verdict-map mechanics. Keep statistics that need flow history in userspace unless profiling justifies another boundary.
