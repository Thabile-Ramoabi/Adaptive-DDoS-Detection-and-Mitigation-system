# Shared contracts

Both students own these interfaces. Agree together before changing them. The exact feature list and observation window are deliberately not frozen. Update a schema, its example, and compatibility notes together.
