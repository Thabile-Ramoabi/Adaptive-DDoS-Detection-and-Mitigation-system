# Temporal LSTM model scaffold.
