# XGBoost model scaffold.
