# Offline preprocessing scaffold aligned to the shared manifest.
