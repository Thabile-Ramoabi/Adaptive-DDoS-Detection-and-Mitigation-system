# ML work area

Student 1 owns data preparation, offline feature mapping, RF/XGBoost/LSTM experiments, mimicry robustness, drift, SHAP, cost analysis, and model evaluation. Promote repeatable work into modules and record dataset provenance.
