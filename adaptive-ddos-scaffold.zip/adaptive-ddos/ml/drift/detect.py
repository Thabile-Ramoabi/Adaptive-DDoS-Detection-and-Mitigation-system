# Concept drift measurement scaffold.
