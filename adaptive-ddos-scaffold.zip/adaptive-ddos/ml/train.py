# Training entry point; implement after feature-manifest review.
