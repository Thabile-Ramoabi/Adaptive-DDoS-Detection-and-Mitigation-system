# Model evaluation entry point.
