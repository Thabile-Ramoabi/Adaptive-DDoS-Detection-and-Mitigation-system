# Controlled mimicry experiment scaffold.
