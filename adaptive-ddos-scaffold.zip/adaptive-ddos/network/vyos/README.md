# Record router image version, interfaces, and reproducible lab commands here.
