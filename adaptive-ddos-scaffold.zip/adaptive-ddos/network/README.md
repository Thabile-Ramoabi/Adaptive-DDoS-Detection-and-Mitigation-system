# Use two Tier 2 border routers A/B, three Tier 3 internal routers C/D/E, and one Tier 1 ISP node.
