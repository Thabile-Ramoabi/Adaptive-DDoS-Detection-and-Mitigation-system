# Document peer identity, key rotation, allowed IPs, and endpoints. Never commit private keys.
