# Adaptive DDoS Detection and Mitigation

Research project by Seeiso Moremoholo and Thabile Ramoabi.

The approved topology has two Tier 2 border routers (A and B) running ML detection and publishing verdicts, three Tier 3 internal routers (C, D, and E) enforcing validated verdicts without ML inference, and a Tier 1 upstream ISP for BGP blackhole escalation.

Read AGENTS.md and docs/architecture.md first. This is an initial scaffold; it does not claim that model performance or latency targets have been measured. Feature definitions and the observation window remain draft decisions.

## Areas

- contracts: versioned interfaces shared by both students
- ml: datasets, feature mapping, models, robustness, drift, explainability, evaluation
- dataplane: XDP/eBPF and userspace map/event handling
- network: Mininet, VyOS, FRR, ExaBGP, WireGuard
- src/adaptive_ddos: shared runtime interfaces
- services: border agent and internal enforcement process
- docs: architecture, integration, allocation, and decisions
- data and artifacts: local-only inputs and generated outputs

Create a Python 3.11+ virtual environment and install development tools with python -m pip install -e ".[dev]". Run python scripts/validate_contracts.py for the standard-library contract checks.

## Use the project offline in VS Code

1. Download and extract `adaptive-ddos-scaffold.zip`.
2. In VS Code, choose **File → Open Folder** and select the extracted `adaptive-ddos` folder.
3. You can browse and edit the scaffold offline. Python tools and the development checks require Python 3.11 or newer; install the optional development dependencies when internet access is available.

From the VS Code terminal, create and activate a virtual environment:

```powershell
# Windows PowerShell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

```bash
# Linux or macOS
python3 -m venv .venv
source .venv/bin/activate
```

Then install the development tools and run the checks:

```bash
python -m pip install -e ".[dev]"
python scripts/validate_contracts.py
python -m pytest
```

The archive contains source scaffolding and example contracts, not datasets, trained models, or Python packages. Keep downloaded datasets and generated model artifacts out of Git; the `.gitignore` already excludes the local data and artifact folders.
