# Store licensed data locally with provenance metadata. Raw data and PCAPs are excluded from Git.
