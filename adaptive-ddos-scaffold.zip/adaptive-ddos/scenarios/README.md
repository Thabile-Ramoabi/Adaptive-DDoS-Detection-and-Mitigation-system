# Record traffic generator, rate, duration, topology, and random seed for every isolated lab scenario.
