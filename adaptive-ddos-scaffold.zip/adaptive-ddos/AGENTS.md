# Project instructions

Treat docs/architecture.md and the final proposal topology as authoritative.

- Tier 2 Border Routers A and B run detection and publish verdicts.
- Tier 3 Internal Routers C, D, and E subscribe and enforce without ML inference.
- Tier 1 is the ISP upstream BGP blackhole boundary.
- Read contracts/v1 before changing an interface. Keep shared definitions there.
- Keep packet handling bounded. Do not assume every CICFlowMeter statistic belongs in XDP.
- Align offline model features with the live exporter and document approximations.
- Do not report targets as measured without experiment output.
- Keep raw data, PCAPs, secrets, private keys, model binaries, and logs out of Git.
- Record consequential changes in docs/decisions.
- Student 1, Seeiso: data, ML, robustness, drift, SHAP, cost analysis, ML evaluation.
- Student 2, Thabile: Linux topology, XDP/eBPF, telemetry export, enforcement, gossip, scenarios.
- Both students own shared contracts and integration.
