# Work allocation

## Student 1: Seeiso
Dataset preparation, offline feature processing, RF/XGBoost/LSTM, mimicry robustness, temporal drift, SHAP, cost-sensitive thresholds, and ML evaluation.

## Student 2: Thabile
Linux and Mininet topology, XDP/eBPF counters and verdict maps, userspace telemetry export, local enforcement, WireGuard gossip, internal subscriptions, and traffic scenarios.

## Joint
Shared contracts, architectural decisions, first end-to-end integration, and result review. Both sides can work against mock records and verdicts before model integration.
