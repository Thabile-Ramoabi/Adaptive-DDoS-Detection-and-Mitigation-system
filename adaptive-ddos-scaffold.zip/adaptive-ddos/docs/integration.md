# Integration order

1. Agree on the feature manifest, window semantics, verdict, gossip authentication, and enforcement command.
2. Student 1 builds an offline baseline and mock inference interface.
3. Student 2 exports synthetic records and applies mock verdicts to local test maps.
4. Compare offline and live features field by field using a common trace.
5. Integrate one attack type, one border router, one model, one action, and one internal subscriber.
6. Expand to the full topology only after the thin path is reproducible.
