# ADR-002: Feature window and response timing

Status: Proposed

Materials mention both a 200 ms observation window and a 5-second aggregation / 5-7-second response path. Resolve with measurement. Record window duration, flow timeout, emission behavior, inference latency, and total time-to-enforcement.
