# ADR-004: Gossip authentication

Status: Proposed

Review WireGuard peer transport, HMAC-SHA256, optional Ed25519 origin signatures, replay handling, canonical serialization, key rotation, trust updates, and expired-message behavior before implementation.
