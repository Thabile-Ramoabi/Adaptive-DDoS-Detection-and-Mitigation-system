# ADR-003: Offline and live feature parity

Status: Proposed

For every model feature, document formula, unit, direction, window, missing-value behavior, and computation source. Compare values from a common packet trace before claiming parity.
