# ADR-001: Final topology

Status: Accepted

Follow originalvandaag.pptx. Tier 2 Border Routers A/B run ML and publish verdicts. Tier 3 Internal Routers C/D/E subscribe and enforce without ML inference. Tier 1 is the upstream BGP blackhole boundary. The draft listing Border A/B/C is stale.
