# Architecture

Tier 1 is the ISP upstream BGP blackhole boundary. Tier 2 Border Routers A and B run ML classification, local enforcement, and gossip publishing. Tier 3 Internal Routers C, D, and E validate subscribed verdicts and enforce them without ML inference.

Packets enter the Tier 2 data plane. XDP handles bounded parsing, counters, and fast map decisions. A userspace process aggregates telemetry into the versioned feature record. The border inference service scores it, the policy selects an action, and the enforcement adapter applies and audits it. Authenticated verdicts travel over the WireGuard control channel to Tier 3.

Feature definitions and timing remain open. Reconcile 200 ms observation references with 5-second aggregation and 5-7-second response claims before hard-coding or reporting them.
