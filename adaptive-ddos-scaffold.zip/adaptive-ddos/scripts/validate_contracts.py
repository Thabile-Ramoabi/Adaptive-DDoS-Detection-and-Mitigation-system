from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = ROOT / "contracts" / "v1"
EXAMPLES = CONTRACTS / "examples"


def load_object(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def require_fields(value: dict, required: set[str], source: Path) -> None:
    missing = required - value.keys()
    if missing:
        raise ValueError(f"{source} is missing fields: {sorted(missing)}")


def main() -> None:
    for path in CONTRACTS.glob("*.schema.json"):
        load_object(path)
    feature = load_object(EXAMPLES / "feature-record.json")
    require_fields(feature, {"schema_version", "record_id", "router_id", "window", "flow", "feature_manifest_version", "features"}, EXAMPLES / "feature-record.json")
    verdict = load_object(EXAMPLES / "verdict.json")
    require_fields(verdict, {"schema_version", "verdict_id", "originator_id", "source_prefix", "score", "action", "issued_at", "expires_at", "hop_count"}, EXAMPLES / "verdict.json")
    if not 0 <= verdict["score"] <= 1:
        raise ValueError("verdict score must be between 0 and 1")
    print("Contract JSON parses and example records contain required fields.")


if __name__ == "__main__":
    main()
